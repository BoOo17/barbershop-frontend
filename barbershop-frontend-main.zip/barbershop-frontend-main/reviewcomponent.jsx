import React, { useState } from 'react';
import { FaStar } from 'react-icons/fa'; //

const ReviewComponent = ({ fodraszId, ugyfelId }) => {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(null);
  const [text, setText] = useState("");

  const handleSubmit = async () => {
    if (rating === 0) return alert("Kérlek, válassz egy csillagot!");

    const response = await fetch('http://localhost/backend/save_review.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fodrasz_id: fodraszId,
        ugyfel_id: ugyfelId,
        pontszam: rating,
        szoveg: text
      })
    });

    const result = await response.json();
    if (result.success) {
      alert(result.message);
      setRating(0);
      setText("");
    }
  };

  return (
    <div className="review-container" style={{ fontFamily: 'Space Grotesk', padding: '20px' }}> {/* */}
      <h3>Hogy tetszett a szolgáltatás?</h3>
      <div style={{ display: 'flex', gap: '5px', marginBottom: '10px' }}>
        {[1, 2, 3, 4, 5].map((star) => {
          const ratingValue = star;
          return (
            <label key={star}>
              <input 
                type="radio" 
                style={{ display: 'none' }} 
                onClick={() => setRating(ratingValue)} 
              />
              <FaStar 
                size={30}
                style={{ cursor: 'pointer', transition: 'color 200ms' }}
                color={ratingValue <= (hover || rating) ? "#ffc107" : "#e4e5e9"}
                onMouseEnter={() => setHover(ratingValue)}
                onMouseLeave={() => setHover(null)}
              />
            </label>
          );
        })}
      </div>
      <textarea 
        style={{ width: '100%', height: '80px', marginBottom: '10px' }}
        placeholder="Írd le a véleményed (opcionális)..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button 
        onClick={handleSubmit}
        style={{ padding: '10px 20px', backgroundColor: '#000', color: '#fff', border: 'none', cursor: 'pointer' }}
      >
        Értékelés beküldése
      </button>
    </div>
  );
};

export default ReviewComponent;