import React, { useState, useEffect } from 'react';
import { FaBell, FaCheckCircle, FaRegEnvelope } from 'react-icons/fa'; //

const NotificationList = ({ fodraszId }) => {
    const [notes, setNotes] = useState([]);

    useEffect(() => {
        const fetchNotes = () => {
            fetch(`http://localhost/backend/get_notifications.php?fodrasz_id=${fodraszId}`)
                .then(res => res.json())
                .then(data => setNotes(data))
                .catch(err => console.error("Hiba az értesítések betöltésekor:", err));
        };

        fetchNotes();
        const interval = setInterval(fetchNotes, 30000); // 30 másodpercenként frissít
        return () => clearInterval(interval);
    }, [fodraszId]);

    return (
        <div style={{ fontFamily: 'Space Grotesk', padding: '15px', border: '1px solid #ddd' }}> {/* */}
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <FaBell color="#e67e22" /> Friss értesítések
            </h3>
            {notes.length === 0 ? (
                <p>Nincs új üzeneted.</p>
            ) : (
                <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                    {notes.map(note => (
                        <div key={note.id} style={{
                            padding: '10px',
                            marginBottom: '5px',
                            borderRadius: '5px',
                            backgroundColor: note.olvasva == '1' ? '#f9f9f9' : '#fff4e6',
                            borderLeft: note.olvasva == '1' ? '4px solid #ccc' : '4px solid #e67e22'
                        }}>
                            <p style={{ margin: 0, fontSize: '14px' }}>{note.uzenet}</p>
                            <small style={{ color: '#888' }}>{note.datum}</small>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default NotificationList;