<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require 'db.php'; // A korábban beállított PDO kapcsolat

$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f_id = $data['fodrasz_id'];
    $u_id = $data['ugyfel_id'];
    $pont = $data['pontszam'];
    $szoveg = $data['szoveg'];

    try {
        $pdo->beginTransaction();

        // 1. Értékelés mentése
        $stmt1 = $pdo->prepare("INSERT INTO velemenyek (Fodrasz_ID, Ugyfel_ID, Pontszam, Szoveg) VALUES (?, ?, ?, ?)");
        $stmt1->execute([$f_id, $u_id, $pont, $szoveg]);

        // 2. Értesítés generálása a fodrásznak
        $uzenet = "Új értékelést kaptál: $pont csillag. Megjegyzés: $szoveg";
        $stmt2 = $pdo->prepare("INSERT INTO ertesitesek (cimzett_id, cimzett_tipus, uzenet) VALUES (?, 'fodrasz', ?)");
        $stmt2->execute([$f_id, $uzenet]);

        $pdo->commit();
        echo json_encode(["success" => true, "message" => "Köszönjük az értékelést!"]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(["success" => false, "message" => "Hiba történt: " . $e->getMessage()]);
    }
}
?>