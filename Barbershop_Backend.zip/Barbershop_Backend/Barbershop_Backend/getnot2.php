<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require 'db.php'; // A meglévő kapcsolatodat használjuk

// A React-ből érkező fodrasz_id lekérése
$fodrasz_id = isset($_GET['fodrasz_id']) ? intval($_GET['fodrasz_id']) : 0;

if ($fodrasz_id > 0) {
    // Csak a fodrásznak szóló, legfrissebb értesítések
    $sql = "SELECT id, uzenet, olvasva, datum 
            FROM ertesitesek 
            WHERE cimzett_id = $fodrasz_id AND cimzett_tipus = 'fodrasz' 
            ORDER BY datum DESC";
            
    $result = $conn->query($sql);
    $notifications = [];

    if ($result) {
        while($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
    }
    echo json_encode($notifications);
} else {
    echo json_encode([]);
}
?>